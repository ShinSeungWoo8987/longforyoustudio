"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var namedTypes;
(function (namedTypes) {
})(namedTypes = exports.namedTypes || (exports.namedTypes = {}));
