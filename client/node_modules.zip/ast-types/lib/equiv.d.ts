import { Fork } from "../types";
export default function (fork: Fork): {
    (a: any, b: any, problemPath?: any): boolean;
    assert(a: any, b: any): void;
};
