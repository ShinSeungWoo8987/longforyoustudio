import { loader } from 'webpack';
declare const ReactRefreshLoader: loader.Loader;
export default ReactRefreshLoader;
