# `@next/react-refresh-utils`

This is an **experimental** package that provides utilities for React Refresh.

Its API is not stable as that of Next.js, nor does it follow semver rules.

**Use it at your own risk**.

## Usage

All entrypoints below must wired into your build tooling for this to work.

### `@next/react-refresh-utils/loader`

### `@next/react-refresh-utils/ReactRefreshWebpackPlugin`

### `@next/react-refresh-utils/runtime`
