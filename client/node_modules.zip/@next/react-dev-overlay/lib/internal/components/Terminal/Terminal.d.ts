import * as React from 'react';
export declare type TerminalProps = {
    content: string;
};
export declare const Terminal: React.FC<TerminalProps>;
