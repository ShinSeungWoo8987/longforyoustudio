declare const styles: string;
export { styles };
