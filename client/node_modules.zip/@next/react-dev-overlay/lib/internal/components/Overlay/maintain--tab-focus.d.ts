export default function ({ context }?: {
    context: any;
}): any;
