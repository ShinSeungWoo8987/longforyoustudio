import * as React from 'react';
export declare type OverlayProps = {
    className?: string;
    fixed?: boolean;
};
declare const Overlay: React.FC<OverlayProps>;
export { Overlay };
