export declare function lock(): void;
export declare function unlock(): void;
