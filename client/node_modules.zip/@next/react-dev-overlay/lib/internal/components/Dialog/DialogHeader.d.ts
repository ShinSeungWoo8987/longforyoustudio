import * as React from 'react';
export declare type DialogHeaderProps = {
    className?: string;
};
declare const DialogHeader: React.FC<DialogHeaderProps>;
export { DialogHeader };
