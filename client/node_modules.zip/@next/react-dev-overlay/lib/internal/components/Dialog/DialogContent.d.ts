import * as React from 'react';
export declare type DialogContentProps = {
    className?: string;
};
declare const DialogContent: React.FC<DialogContentProps>;
export { DialogContent };
