import * as React from 'react';
export declare type DialogBodyProps = {
    className?: string;
};
declare const DialogBody: React.FC<DialogBodyProps>;
export { DialogBody };
