import { StackFrame } from 'stacktrace-parser';
export declare function parseStack(stack: string): StackFrame[];
