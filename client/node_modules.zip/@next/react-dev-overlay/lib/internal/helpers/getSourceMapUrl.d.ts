export declare function getSourceMapUrl(fileContents: string): string | null;
