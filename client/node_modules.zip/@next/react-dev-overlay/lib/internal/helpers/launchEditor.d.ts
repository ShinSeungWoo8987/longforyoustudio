declare function launchEditor(fileName: string, lineNumber: number, colNumber: number): void;
export { launchEditor };
