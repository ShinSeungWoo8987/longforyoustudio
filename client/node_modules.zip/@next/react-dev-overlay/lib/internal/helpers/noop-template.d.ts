export declare function noop(strings: TemplateStringsArray, ...keys: readonly string[]): string;
