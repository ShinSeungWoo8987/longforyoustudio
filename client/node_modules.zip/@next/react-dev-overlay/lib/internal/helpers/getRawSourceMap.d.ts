import { RawSourceMap } from 'source-map';
export declare function getRawSourceMap(fileContents: string): RawSourceMap | null;
