import * as React from 'react';
declare const ReactDevOverlay: React.FunctionComponent;
export default ReactDevOverlay;
