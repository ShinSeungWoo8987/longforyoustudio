import * as React from 'react';
export declare type BuildErrorProps = {
    message: string;
};
export declare const BuildError: React.FC<BuildErrorProps>;
export declare const styles: string;
