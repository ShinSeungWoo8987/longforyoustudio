/// <reference types="react" />
export declare function CssReset(): JSX.Element;
