/// <reference types="react" />
export declare function ComponentStyles(): JSX.Element;
