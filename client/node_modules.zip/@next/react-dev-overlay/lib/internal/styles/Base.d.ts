/// <reference types="react" />
export declare function Base(): JSX.Element;
