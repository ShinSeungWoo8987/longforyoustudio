export declare function useOnClickOutside(el: Node | null, handler: ((e: MouseEvent | TouchEvent) => void) | undefined): void;
