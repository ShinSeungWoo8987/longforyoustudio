# `@next/react-dev-overlay`

A development-only overlay for developing React applications.
