# Installation
> `npm install --save @types/scheduler`

# Summary
This package contains type definitions for scheduler (https://reactjs.org/).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/scheduler

Additional Details
 * Last updated: Tue, 15 Oct 2019 18:43:08 GMT
 * Dependencies: none
 * Global values: none

# Credits
These definitions were written by Nathan Bierema <https://github.com/Methuselah96>, and Sebastian Silbermann <https://github.com/eps1lon>.
