# Installation
> `npm install --save @types/react-html-parser`

# Summary
This package contains type definitions for react-html-parser (https://github.com/wrakky/react-html-parser#readme).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/react-html-parser

Additional Details
 * Last updated: Wed, 17 Jul 2019 21:36:30 GMT
 * Dependencies: @types/react, @types/htmlparser2
 * Global values: none

# Credits
These definitions were written by Spencer Elliott <https://github.com/elliottsj>, and Wooram Jun <https://github.com/chatoo2412>.
