# Installation
> `npm install --save @types/react-lazy-load-image-component`

# Summary
This package contains type definitions for react-lazy-load-image-component (https://github.com/Aljullu/react-lazy-load-image-component#readme).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/react-lazy-load-image-component.

### Additional Details
 * Last updated: Fri, 31 Jul 2020 20:41:29 GMT
 * Dependencies: [@types/react](https://npmjs.com/package/@types/react)
 * Global values: none

# Credits
These definitions were written by [Dan Vanderkam](https://github.com/danvk), [Diego Chavez](https://github.com/diegochavez), [Truong Hoang Dung](https://github.com/revskill10), and [Kodai Suzuki](https://github.com/kodai3).
