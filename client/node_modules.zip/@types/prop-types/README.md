# Installation
> `npm install --save @types/prop-types`

# Summary
This package contains type definitions for prop-types (https://github.com/reactjs/prop-types).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/prop-types

Additional Details
 * Last updated: Tue, 24 Sep 2019 20:14:29 GMT
 * Dependencies: none
 * Global values: none

# Credits
These definitions were written by DovydasNavickas <https://github.com/DovydasNavickas>, Ferdy Budhidharma <https://github.com/ferdaber>, and Sebastian Silbermann <https://github.com/eps1lon>.
