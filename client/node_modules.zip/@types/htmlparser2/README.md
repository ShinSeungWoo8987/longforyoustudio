# Installation
> `npm install --save @types/htmlparser2`

# Summary
This package contains type definitions for htmlparser2 (https://github.com/fb55/htmlparser2/).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/htmlparser2.

### Additional Details
 * Last updated: Tue, 08 Sep 2020 21:01:43 GMT
 * Dependencies: [@types/domhandler](https://npmjs.com/package/@types/domhandler), [@types/domutils](https://npmjs.com/package/@types/domutils), [@types/node](https://npmjs.com/package/@types/node)
 * Global values: none

# Credits
These definitions were written by [James Roland Cabresos](https://github.com/staticfunction), [Linus Unnebäck](https://github.com/LinusU), [Johan Davidsson](https://github.com/johandavidson), and [GP](https://github.com/paambaati).
