# Installation
> `npm install --save @types/domutils`

# Summary
This package contains type definitions for domutils (https://github.com/FB55/domutils#readme).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/domutils.

### Additional Details
 * Last updated: Tue, 08 Sep 2020 21:01:41 GMT
 * Dependencies: [@types/domhandler](https://npmjs.com/package/@types/domhandler)
 * Global values: none

# Credits
These definitions were written by [Johan Davidsson](https://github.com/johandavidson).
