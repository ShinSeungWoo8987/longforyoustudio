# Installation
> `npm install --save @types/hoist-non-react-statics`

# Summary
This package contains type definitions for hoist-non-react-statics ( https://github.com/mridgway/hoist-non-react-statics#readme ).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/hoist-non-react-statics

Additional Details
 * Last updated: Thu, 04 Apr 2019 18:42:22 GMT
 * Dependencies: @types/react
 * Global values: none

# Credits
These definitions were written by JounQin <https://github.com/JounQin>, James Reggio <https://github.com/jamesreggio>.
