// Expose `JSX` namespace in `global` namespace
import './';
