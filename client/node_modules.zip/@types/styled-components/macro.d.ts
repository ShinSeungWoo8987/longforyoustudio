export { default } from '.';
export * from '.';

/**
 * Recommended: also `import {} from 'styled-components/cssprop'`,
 * or augment react's `Attribute` interface with your own version.
 */
